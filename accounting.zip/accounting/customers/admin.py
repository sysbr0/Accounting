
from django.contrib import admin
from .models import Costomers

admin.site.register(Costomers)
