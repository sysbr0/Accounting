from django.contrib import admin
from .models import MoneySource , GeneralPayment
admin.site.register(MoneySource)
admin.site.register(GeneralPayment)

